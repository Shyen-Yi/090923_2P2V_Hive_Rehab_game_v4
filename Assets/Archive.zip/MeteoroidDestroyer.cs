using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteoroidDestroyer : MonoBehaviour
{

    private Camera mainCamera;
    private Renderer rendererComponent;

    private void Start()
    {
        mainCamera = Camera.main;
        rendererComponent = GetComponent<Renderer>();
    }

    private void Update()
    {
        // Check if the object is completely outside the camera's view frustum
        if (!IsVisible())
        {
            Destroy(gameObject);
        }
    }

    private bool IsVisible()
    {
        if (rendererComponent == null || !rendererComponent.isVisible)
        {
            return false;
        }

        // Get the object's screen position
        Vector3 screenPoint = mainCamera.WorldToViewportPoint(transform.position);

        // Check if it's outside the viewport
        return screenPoint.x > 0 && screenPoint.x < 1 && screenPoint.y > 0 && screenPoint.y < 1;
    }
 
    
    void OnTriggerEnter2D(Collider2D collision)
    {
        // Destroy meteoroids when they leave a certain area
        if (collision.CompareTag("Meteoroid"))
        {
            Destroy(collision.gameObject);
        }
    }
}