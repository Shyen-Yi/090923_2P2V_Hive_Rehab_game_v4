using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Meteoroid : MonoBehaviour
{
        private bool isSnapped = false;
        private Transform target;

     private void Start()
    {
        target = GameObject.Find("Meteroiod").transform; // Replace "TargetObject" with the name of your target object.
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0) && !isSnapped)
        {
            Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            RaycastHit2D hit = Physics2D.Raycast(mousePosition, Vector2.zero);

            if (hit.collider != null && hit.collider.gameObject == target.gameObject)
            {
                // Snap the object to the target.
                transform.position = target.position;
                isSnapped = true;
            }
        }
    }
    
        // public float speed = 5.0f;

        // Add any other meteoroid-related logic here

        /// <summary>
        /// Start is called on the frame when a script is enabled just before
        /// any of the Update methods is called the first time.
        /// </summary>

    
}